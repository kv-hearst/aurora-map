/*
 PolarMap.js {VERSION}
 (c) 2014-2018 Arctic Connect, Geo Sensor Web Lab
*/
