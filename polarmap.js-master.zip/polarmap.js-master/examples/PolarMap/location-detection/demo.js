// Initialization
$(document).ready(function() {
  Autosize.enable();

  // Load PolarMap
  var map = polarMap('xmap', {
    locate: true
  });
});

